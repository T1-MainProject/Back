from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain.agents import Tool, initialize_agent, AgentType
from langchain_qdrant import QdrantVectorStore, FastEmbedSparse, RetrievalMode
from qdrant_client import QdrantClient
from dotenv import load_dotenv
import requests, os

load_dotenv()

app = FastAPI()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:3002"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API Keys
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
QDRANT_API_KEY = os.getenv("QDRANT_API_KEY")
QDRANT_URL = os.getenv("QDRANT_URL")
HF_TOKEN = os.getenv("HF_TOKEN")

# LLM 설정
llm = ChatOpenAI(model="gpt-4o", openai_api_key=OPENAI_API_KEY)

# Qdrant 설정
embedding_model = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)
sparse_embeddings = FastEmbedSparse(model_name="Qdrant/bm25", token=HF_TOKEN)

qdrant_client = QdrantClient(url=QDRANT_URL, api_key=QDRANT_API_KEY)
vector_store = QdrantVectorStore(
    client=qdrant_client,
    collection_name="appointment_vector",
    embedding=embedding_model,
    sparse_embedding=sparse_embeddings,
    retrieval_mode=RetrievalMode.HYBRID,
    vector_name="dense",
    sparse_vector_name="sparse",
)
retriever = vector_store.as_retriever(search_kwargs={"k": 5})

# 노드 서버 주소
NODE_SERVER_URL = "http://localhost:3002"

# 예약 생성
def create_reservation(input_str: str) -> str:
    try:
        parts = input_str.replace('"', '').replace("'", '').strip().split(',')
        if len(parts) != 4:
            return f"예약 형식이 잘못되었습니다. 'userId,date,time,purpose' 형식으로 입력해주세요. 예: 6,2025-07-26,15:00,진료"

        userId, date, time, purpose = [p.strip() for p in parts]

        # 날짜 보정
        if date.count('-') == 1:
            date = f"2025-{date}"
        elif date.count('-') == 2 and not date.startswith("2024") and not date.startswith("2025"):
            date = f"2025-{date.split('-')[1]}-{date.split('-')[2]}"

        payload = { "userId": userId, "date": date, "time": time, "purpose": purpose }
        response = requests.post(f"{NODE_SERVER_URL}/api/reservations", json=payload)
        response.raise_for_status()
        return f"{date} {time}에 '{purpose}' 예약이 완료되었습니다."

    except requests.exceptions.HTTPError as http_err:
        return f"예약 실패: {http_err.response.text}"
    except Exception as e:
        return f"예약 요청 처리 중 오류 발생: {e}"

# 예약 취소
def delete_reservation(userId: str) -> str:
    try:
        response = requests.delete(f"{NODE_SERVER_URL}/api/reservations/user/{userId}")
        response.raise_for_status()
        return f"{userId}번 사용자의 예약이 모두 취소되었습니다."
    except Exception as e:
        return f"예약 취소 실패: {e}"

# Qdrant 유사 검색
def qdrant_appointment_search(query: str) -> str:
    docs = retriever.invoke(query)
    return "\n".join([doc.page_content for doc in docs]) or "관련 예약 정보를 찾을 수 없습니다."

# 도구 등록
tools = [
    Tool.from_function(
        func=create_reservation,
        name="CreateReservation",
        description="예약을 생성합니다. 형식: 'userId,date,time,purpose' 예: 6,2025-07-26,15:00,진료"
    ),
    Tool.from_function(
        func=delete_reservation,
        name="DeleteReservation",
        description="특정 사용자 ID의 예약을 모두 취소합니다. 입력 예: 6"
    ),
    Tool.from_function(
        func=qdrant_appointment_search,
        name="AppointmentSearch",
        description="예약 관련 질문에 대해 Qdrant에서 유사 문장을 검색합니다."
    )
]

# 에이전트 생성
agent = initialize_agent(
    tools=tools,
    llm=llm,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True,
    handle_parsing_errors=True,
)

# Agent 호출 API
@app.post("/invoke-agent/")
async def invoke_agent(request: dict):
    message = request.get("message")
    userId = request.get("userId")
    if not message or not userId:
        return {"error": "message와 userId는 필수입니다."}

    prompt = (
        f"userId는 {userId}이고, 사용자의 요청은 다음과 같아: '{message}'.\n"
        f"예약 생성이나 예약 취소 요청이라면 반드시 알맞은 Tool을 사용해서 처리해줘.\n"
        f"예약 관련 문장이 아니라면 Tool을 사용하지 말고 일반적인 대화를 해줘.\n"
        f"항상 한국어로만 대답해."
    )

    result = await agent.ainvoke(prompt)
    return {"response": result.get("output", "응답을 생성하지 못했습니다.")}
